"""MONITOR DE CONCENTRACION EN ESTUDIO  -  todo en un solo archivo.

Carpeta necesaria:
    monitor_atencion.py
    assets/alerta.mp4     (video que salta cuando te distraes)
    assets/alerta.wav     (audio del video)

Ejecutar:   python monitor_atencion.py
Teclas:     Q salir | C recalibrar (5 pasos: centro, izquierda, derecha, arriba, abajo) | D ver numeros
"""
import os
import sys

os.chdir(os.path.dirname(os.path.abspath(__file__)))  # las rutas assets/... son relativas a este archivo

try:
    import cv2
    import numpy as np
    import mediapipe as mp
    from PIL import Image, ImageSequence
except ImportError as e:
    print("\nFALTA UNA LIBRERIA:", e)
    print("Instala todo con este comando y vuelve a ejecutar:\n")
    print('  pip install "numpy<2" opencv-python==4.10.0.84 mediapipe==0.10.14 pillow pygame\n')
    sys.exit(1)

import argparse
import csv
import json
import time
import urllib.request
from datetime import datetime



# ===================== CONFIGURACION =====================

# --- Camara -----------------------------------------------------------------
CAMARA_INDEX = None    # None = la busca sola

# --- Logica de atencion -----------------------------------------------------
DISTRACT_AFTER = 0.8   # s sin mirar la pantalla antes de alertar (mas bajo = alerta mas rapida)
RECOVER_AFTER = 0.4    # s mirando la pantalla para dar por terminada la distraccion

# --- Calibracion de la pantalla (5 pasos: centro, izquierda, derecha, arriba, abajo) ---
CALIB_STEP_SECONDS = 5.0   # duracion de cada paso
CALIB_SKIP = 2.0           # s iniciales de cada paso que se ignoran (tiempo para mover la mirada)

# --- Direccion de la mirada: cabeza (toda la cara) + iris -------------------------------
EYE_H_GAIN = 60.0      # cuantos grados suma el iris (horizontal) por unidad de ratio
EYE_V_GAIN = 25.0      # idem vertical
MARGIN_H_FRAC = 0.25   # tolerancia extra a los lados de la pantalla (fraccion de su ancho)
MARGIN_V_FRAC = 0.20   # tolerancia extra arriba/abajo
MARGIN_MIN_DEG = 6.0   # tolerancia minima en grados
EYE_CLOSED_T = 0.10    # apertura del ojo por debajo de la cual se consideran cerrados

# --- Alertas ----------------------------------------------------------------
GIF_PATH = "assets/alerta.mp4"     # GIF o video (mp4...). También: --gif ruta
GIF_WIDTH = 480                    # ancho al que se redimensiona
SOUND_PATH = "assets/alerta.wav"   # audio del video; si no existe se genera un pitido

# --- MQTT (opcional) --------------------------------------------------------
MQTT_HOST = "localhost"            # IP del broker (p. ej. Mosquitto en tu PC)
MQTT_PORT = 1883
MQTT_PREFIX = "estudio"            # temas: estudio/tiempo, estudio/atencion, estudio/alertas ...
MQTT_PERIODO = 5.0                 # s entre publicaciones de estudio/tiempo

# --- Registro ---------------------------------------------------------------
CSV_PATH = "registro_atencion.csv"



# ===================== ATENCION (estados) =====================



class AttentionMonitor:
    def __init__(self, distract_after=1.5, recover_after=0.6):
        self.distract_after = distract_after
        self.recover_after = recover_after
        self.state = "ATENTO"
        self.distracted_total = 0.0   # segundos acumulados distraído
        self.count = 0                # número de distracciones
        self.start = None
        self._last = None
        self._off_since = None
        self._on_since = None
        self._distract_start = None

    def study_time(self, now):
        return 0.0 if self.start is None else now - self.start

    def update(self, looking, now):
        """Devuelve la lista de eventos ocurridos en este instante:
        'DISTRAIDO' (empezó una distracción) y/o 'ATENTO' (terminó)."""
        if self.start is None:
            self.start = self._last = now
        dt = now - self._last
        self._last = now
        events = []

        if self.state == "DISTRAIDO":
            self.distracted_total += dt

        if looking:
            self._off_since = None
            if self.state == "DISTRAIDO":
                if self._on_since is None:
                    self._on_since = now
                if now - self._on_since >= self.recover_after:
                    self.state = "ATENTO"
                    self._on_since = None
                    events.append("ATENTO")
        else:
            self._on_since = None
            if self.state == "ATENTO":
                if self._off_since is None:
                    self._off_since = now
                if now - self._off_since >= self.distract_after:
                    self.state = "DISTRAIDO"
                    self.count += 1
                    events.append("DISTRAIDO")
        return events


# ===================== DETECCION DE MIRADA =====================

import os
import urllib.request

import cv2
import numpy as np
import mediapipe as mp


MODEL_URL = ("https://storage.googleapis.com/mediapipe-models/face_landmarker/"
             "face_landmarker/float16/1/face_landmarker.task")
MODEL_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "face_landmarker.task")

# Índices de la malla facial de MediaPipe (468 puntos + 10 del iris)
NOSE, FACE_A, FACE_B, CHIN = 1, 234, 454, 152
EYES = [  # (esquina, esquina, párpado sup., párpado inf., centro del iris)
    (33, 133, 159, 145, 468),
    (362, 263, 386, 374, 473),
]


class FaceTracker:
    """Devuelve los 478 puntos del rostro en píxeles (o None si no hay rostro)."""

    def __init__(self):
        self._legacy = None
        self._task = None
        if hasattr(mp, "solutions") and hasattr(mp.solutions, "face_mesh"):
            self._legacy = mp.solutions.face_mesh.FaceMesh(
                max_num_faces=1, refine_landmarks=True,
                min_detection_confidence=0.5, min_tracking_confidence=0.5)
        else:  # versiones nuevas de MediaPipe: API Tasks (necesita el modelo .task)
            from mediapipe.tasks import python as mp_python
            from mediapipe.tasks.python import vision
            self._ensure_model()
            opts = vision.FaceLandmarkerOptions(
                base_options=mp_python.BaseOptions(model_asset_path=MODEL_PATH),
                running_mode=vision.RunningMode.VIDEO, num_faces=1)
            self._task = vision.FaceLandmarker.create_from_options(opts)
            self._ts = 0

    @staticmethod
    def _ensure_model():
        if not os.path.exists(MODEL_PATH):
            print("Descargando modelo de MediaPipe (solo la primera vez)...")
            urllib.request.urlretrieve(MODEL_URL, MODEL_PATH)

    def process(self, frame_bgr, now_ms):
        h, w = frame_bgr.shape[:2]
        rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        if self._legacy is not None:
            res = self._legacy.process(rgb)
            if not res.multi_face_landmarks:
                return None
            lms = res.multi_face_landmarks[0].landmark
        else:
            img = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
            self._ts = max(self._ts + 1, int(now_ms))
            res = self._task.detect_for_video(img, self._ts)
            if not res.face_landmarks:
                return None
            lms = res.face_landmarks[0]
        return np.array([(p.x * w, p.y * h, p.z * w) for p in lms], dtype=np.float32)



# ---- Pose de TODA la cara: se ajusta la nube de 468 puntos contra la pose de referencia ----
def forma_cara(pts):
    """Nube 3D de los 468 puntos de la cara, centrada y normalizada (independiente de distancia)."""
    X = pts[:468].astype(np.float64)
    X = X - X.mean(axis=0)
    return X / np.sqrt((X ** 2).sum() / len(X))


def rotacion_entre(A, B):
    """Rotacion R (3x3) que lleva la nube A hacia la nube B (Kabsch/SVD, usa todos los puntos)."""
    U, _, Vt = np.linalg.svd(A.T @ B)
    d = np.sign(np.linalg.det(Vt.T @ U.T))
    return Vt.T @ np.diag([1.0, 1.0, d]) @ U.T


def angulos(R):
    """(yaw, pitch) en grados. yaw + = cara hacia la derecha del usuario; pitch + = hacia abajo."""
    theta = np.arctan2(R[0, 2], R[2, 2])
    phi = np.arctan2(-R[1, 2], R[1, 1])
    return float(-np.degrees(theta)), float(np.degrees(phi))


def ratios_ojos(pts):
    """(eye_h, eye_v, apertura) a partir de los puntos del iris. None si no hay iris."""
    if len(pts) < 478:
        return None, None, None
    hs, vs, ops = [], [], []
    for c1, c2, up, low, iris in EYES:
        xl, xr = sorted((pts[c1][0], pts[c2][0]))
        width = max(xr - xl, 1e-6)
        lid = pts[low][1] - pts[up][1]
        ops.append(lid / width)
        hs.append((pts[iris][0] - xl) / width)
        if lid > 1e-6:
            vs.append((pts[iris][1] - pts[up][1]) / lid)
    return float(np.mean(hs)), (float(np.mean(vs)) if vs else 0.5), float(np.mean(ops))


def iris_points(pts):
    if pts is None or len(pts) < 478:
        return []
    return [tuple(map(int, pts[i][:2])) for i in (468, 473)]


def medir(pts, ref, base_ojo):
    """Dict con yaw, pitch, gx, gy (grados), apertura. gx/gy = hacia donde mira (cabeza + ojos)."""
    if pts is None or len(pts) < 468:
        return None
    yaw, pitch = angulos(rotacion_entre(ref, forma_cara(pts)))
    eh, ev, ap = ratios_ojos(pts)
    gx = yaw + (EYE_H_GAIN * (eh - base_ojo[0]) if eh is not None else 0.0)
    gy = pitch + (EYE_V_GAIN * (ev - base_ojo[1]) if ev is not None else 0.0)
    return {"yaw": yaw, "pitch": pitch, "gx": gx, "gy": gy, "open": ap}


def pitido():
    try:
        import winsound
        winsound.Beep(1000, 150)
    except Exception:
        print("\a", end="", flush=True)


class Calibrator:
    """Aprende tu pantalla: mira centro, izquierda, derecha, arriba y abajo (5 pasos)."""
    PASOS = [("CENTRO", "MIRA EL CENTRO DE LA PANTALLA"),
             ("IZQ", "MIRA EL BORDE IZQUIERDO DE LA PANTALLA"),
             ("DER", "MIRA EL BORDE DERECHO DE LA PANTALLA"),
             ("ARR", "MIRA EL BORDE SUPERIOR DE LA PANTALLA"),
             ("ABA", "MIRA EL BORDE INFERIOR DE LA PANTALLA")]

    def __init__(self):
        self.reset()

    def reset(self):
        self.i, self.t0, self.samples = 0, None, []
        self.ref, self.base_ojo, self.puntos = None, (0.5, 0.5), {}
        self.done, self.zona = False, None
        self.izq_negativo = self.arriba_negativo = True

    @property
    def paso_texto(self):
        return f"[{self.i + 1}/{len(self.PASOS)}] {self.PASOS[self.i][1]}"

    def progreso(self, now):
        return 0.0 if self.t0 is None else min(1.0, (now - self.t0) / CALIB_STEP_SECONDS)

    def update(self, pts, now):
        if self.done:
            return
        if self.t0 is None:
            self.t0 = now
            pitido()
        if pts is not None and len(pts) >= 468 and now - self.t0 >= CALIB_SKIP:
            eh, ev, ap = ratios_ojos(pts)
            if ap is None or ap > EYE_CLOSED_T:
                if self.i == 0:
                    self.samples.append((forma_cara(pts), eh if eh is not None else 0.5, ev if ev is not None else 0.5))
                else:
                    m = medir(pts, self.ref, self.base_ojo)
                    self.samples.append((m["gx"], m["gy"]))
        if now - self.t0 >= CALIB_STEP_SECONDS and len(self.samples) >= 8:
            self._cerrar_paso()

    def _cerrar_paso(self):
        nombre = self.PASOS[self.i][0]
        if self.i == 0:
            self.ref = np.mean([s[0] for s in self.samples], axis=0)
            self.base_ojo = (float(np.mean([s[1] for s in self.samples])), float(np.mean([s[2] for s in self.samples])))
            self.puntos["CENTRO"] = (0.0, 0.0)
        else:
            self.puntos[nombre] = (float(np.median([s[0] for s in self.samples])),
                                   float(np.median([s[1] for s in self.samples])))
        self.i += 1
        self.t0, self.samples = None, []
        if self.i >= len(self.PASOS):
            self._calcular_zona()
            self.done = True

    def _calcular_zona(self):
        p = self.puntos
        xs = [p["CENTRO"][0], p["IZQ"][0], p["DER"][0]]
        ys = [p["CENTRO"][1], p["ARR"][1], p["ABA"][1]]
        x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
        mx = max(MARGIN_MIN_DEG, MARGIN_H_FRAC * (x1 - x0))
        my = max(MARGIN_MIN_DEG, MARGIN_V_FRAC * (y1 - y0))
        self.zona = (x0 - mx, x1 + mx, y0 - my, y1 + my)
        self.izq_negativo = p["IZQ"][0] < p["DER"][0]
        self.arriba_negativo = p["ARR"][1] < p["ABA"][1]


def juzgar(m, cal):
    """Devuelve (mirando: bool, etiqueta: str)."""
    if m is None:
        return False, "SIN ROSTRO"
    if m["open"] is not None and m["open"] < EYE_CLOSED_T:
        return False, "NO MIRA (OJOS CERRADOS)"
    x0, x1, y0, y1 = cal.zona
    gx, gy = m["gx"], m["gy"]
    # cuanto se sale de la zona de pantalla, relativo al tamaño de la zona
    ex = max(x0 - gx, gx - x1, 0) / max(x1 - x0, 1e-6)
    ey = max(y0 - gy, gy - y1, 0) / max(y1 - y0, 1e-6)
    if ex == 0 and ey == 0:
        return True, "MIRANDO PANTALLA"
    if ex >= ey:
        lado_neg = gx < x0
        izq = lado_neg == cal.izq_negativo
        return False, "NO MIRA (IZQUIERDA)" if izq else "NO MIRA (DERECHA)"
    lado_neg = gy < y0
    arriba = lado_neg == cal.arriba_negativo
    return False, "NO MIRA (ARRIBA)" if arriba else "NO MIRA (ABAJO)"



# ===================== ALERTAS (video + sonido) =====================

import os
import time

import cv2
import numpy as np
from PIL import Image, ImageSequence

WINDOW = "ALERTA"


def cargar_video(path, width):
    """Lee un video (mp4, avi, ...) -> (fotogramas BGR, duraciones en s)."""
    cap = cv2.VideoCapture(path)
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    frames = []
    while True:
        ok, fr = cap.read()
        if not ok:
            break
        h = int(fr.shape[0] * width / fr.shape[1])
        frames.append(cv2.resize(fr, (width, h)))
    cap.release()
    if not frames:
        raise ValueError("No pude leer fotogramas del video")
    return frames, [1.0 / fps] * len(frames)


def cargar_gif(path, width):
    """Lee un GIF animado o un video -> (lista de fotogramas BGR, lista de duraciones en s)."""
    if path.lower().endswith((".mp4", ".avi", ".mov", ".mkv", ".webm")):
        return cargar_video(path, width)
    frames, durations = [], []
    with Image.open(path) as im:
        for fr in ImageSequence.Iterator(im):
            rgb = fr.convert("RGB")
            h = int(rgb.height * width / rgb.width)
            arr = np.array(rgb.resize((width, h)))
            frames.append(cv2.cvtColor(arr, cv2.COLOR_RGB2BGR))
            durations.append(max(fr.info.get("duration", 80), 20) / 1000.0)
    if not frames:
        raise ValueError("El GIF no tiene fotogramas")
    return frames, durations


def _beep(sr=44100):
    t = np.linspace(0, 0.35, int(sr * 0.35), endpoint=False)
    tone = (0.5 * np.sin(2 * np.pi * 880 * t) * 32767).astype(np.int16)
    return np.concatenate([tone, np.zeros(int(sr * 0.25), dtype=np.int16)])


class AlertManager:
    def __init__(self, mode, gif_path, gif_width, sound_path):
        """mode: 'sonido', 'imagen' o 'ambos'."""
        self.use_sound = mode in ("sonido", "ambos")
        self.use_image = mode in ("imagen", "ambos")
        self.active = False
        self._t0 = 0.0
        self._sound = None
        self._frames = None

        if self.use_image:
            try:
                self._frames, self._durs = cargar_gif(gif_path, gif_width)
                self._total = sum(self._durs)
            except Exception as e:
                print(f"[alerta] No pude cargar '{gif_path}': {e}")
                self.use_image = False

        if self.use_sound:
            try:
                import pygame
                pygame.mixer.init(frequency=44100, size=-16, channels=1)
                if os.path.exists(sound_path):
                    self._sound = pygame.mixer.Sound(sound_path)
                else:
                    self._sound = pygame.sndarray.make_sound(_beep())
            except Exception as e:
                print(f"[alerta] Sonido no disponible ({e}). Instala pygame: pip install pygame")
                self.use_sound = False

    def start(self):
        if self.active:
            return
        self.active = True
        self._t0 = time.time()
        if self.use_sound and self._sound:
            self._sound.play(loops=-1)

    def stop(self):
        if not self.active:
            return
        self.active = False
        if self.use_sound and self._sound:
            self._sound.stop()
        if self.use_image:
            try:
                cv2.destroyWindow(WINDOW)
            except cv2.error:
                pass

    def tick(self):
        """Llamar en cada ciclo: dibuja el fotograma del GIF que toca según el tiempo."""
        if not (self.active and self.use_image):
            return
        pos = (time.time() - self._t0) % self._total
        for frame, dur in zip(self._frames, self._durs):
            if pos < dur:
                break
            pos -= dur
        cv2.imshow(WINDOW, frame)
        try:
            cv2.setWindowProperty(WINDOW, cv2.WND_PROP_TOPMOST, 1)
        except cv2.error:
            pass

# ===================== MQTT / ESP32 (opcional) =====================

import json


class MqttLink:
    def __init__(self, host, port, prefix="estudio"):
        self.prefix = prefix
        self.sensores = {"presencia": None, "ruido": None}
        self.connected = False
        self._client = None
        try:
            import paho.mqtt.client as mqtt
        except ImportError:
            print("[mqtt] paho-mqtt no instalado (pip install paho-mqtt). Sigo sin MQTT.")
            return
        try:
            self._client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id="pc-monitor-atencion")
        except AttributeError:  # paho-mqtt 1.x
            self._client = mqtt.Client(client_id="pc-monitor-atencion")
        self._client.on_connect = self._on_connect
        self._client.on_disconnect = lambda *a, **k: setattr(self, "connected", False)
        self._client.on_message = self._on_message
        try:
            self._client.connect_async(host, port, keepalive=30)
            self._client.loop_start()
        except Exception as e:
            print(f"[mqtt] No pude iniciar la conexión: {e}")
            self._client = None

    def _on_connect(self, client, userdata, flags, rc, *args):
        self.connected = True
        client.subscribe([(f"{self.prefix}/presencia", 0), (f"{self.prefix}/ruido", 0)])

    def _on_message(self, client, userdata, msg):
        nombre = msg.topic.rsplit("/", 1)[-1]
        if nombre in self.sensores:
            try:
                self.sensores[nombre] = int(msg.payload.decode())
            except ValueError:
                pass

    def publish(self, tema, payload, retain=False):
        if self._client and self.connected:
            if not isinstance(payload, str):
                payload = json.dumps(payload)
            self._client.publish(f"{self.prefix}/{tema}", payload, retain=retain)

    def close(self):
        if self._client:
            self._client.loop_stop()
            self._client.disconnect()


# ===================== PROGRAMA PRINCIPAL =====================
VERDE, ROJO, AMARILLO, BLANCO = (60, 200, 60), (50, 50, 230), (0, 200, 255), (255, 255, 255)

def fmt(seg):
    seg = int(seg)
    return f"{seg // 60:02d}:{seg % 60:02d}"


def etiqueta(img, texto, x, y, fondo, escala=0.6):
    (w, h), _ = cv2.getTextSize(texto, cv2.FONT_HERSHEY_SIMPLEX, escala, 2)
    cv2.rectangle(img, (x, y - h - 8), (x + w + 12, y + 6), fondo, -1)
    cv2.putText(img, texto, (x + 6, y), cv2.FONT_HERSHEY_SIMPLEX, escala, BLANCO, 2, cv2.LINE_AA)


def pedir_modo():
    print("¿Cómo quieres que te alerte cuando te distraigas?")
    print("  1) Sonido   2) Imagen (GIF)   3) Ambos")
    return {"1": "sonido", "2": "imagen", "3": "ambos"}.get(input("Opción [3]: ").strip(), "ambos")


def _probar(idx, backend):
    cap = cv2.VideoCapture(idx, backend)
    if not cap.isOpened():
        cap.release()
        return None, 0.0
    brillo = 0.0
    for _ in range(15):  # los primeros cuadros suelen salir negros: se descartan
        ok, fr = cap.read()
        if ok and fr is not None:
            brillo = max(brillo, float(fr.mean()))
        time.sleep(0.05)
    return cap, brillo


def abrir_camara(idx):
    """Busca una camara que de imagen real (no negra). Sirve con Camo, Iriun, DroidCam, etc."""
    backends = [cv2.CAP_DSHOW, cv2.CAP_MSMF, cv2.CAP_ANY] if os.name == "nt" else [cv2.CAP_ANY]
    indices = [idx] if idx is not None else range(6)
    print("Buscando camara (puede tardar unos segundos)...")
    for i in indices:
        for b in backends:
            cap, brillo = _probar(i, b)
            estado = "no abre" if cap is None else f"abre, brillo {brillo:.0f}"
            print(f"  camara {i} / metodo {b}: {estado}")
            if cap is not None and brillo > 8:
                print(f"-> Usando camara {i}\n")
                return cap
            if cap is not None:
                cap.release()
    raise SystemExit("\nNo encontre ninguna camara con imagen. Abre Camo Studio (o tu app de camara), "
                     "conecta el telefono, cierra otras apps que usen la camara y vuelve a ejecutar.\n"
                     "Si sabes el numero: python monitor_atencion.py --camara 1")


def log_csv(ruta, evento, valor=""):
    nuevo = not os.path.exists(ruta)
    with open(ruta, "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if nuevo:
            w.writerow(["fecha_hora", "evento", "valor"])
        w.writerow([datetime.now().isoformat(timespec="seconds"), evento, valor])




def dibujar_cara(frame, pts):
    """Dibuja TODOS los puntos de la cara (tenues) y el iris (verde)."""
    if pts is None:
        return
    for x, y in pts[:468, :2].astype(int):
        cv2.circle(frame, (int(x), int(y)), 1, (150, 150, 150), -1)
    for p in iris_points(pts):
        cv2.circle(frame, p, 3, (0, 255, 0), -1)


def flecha_paso(frame, nombre, restante):
    """Flecha grande hacia el borde que hay que mirar en el paso actual (vista de espejo = tu izquierda es la izquierda)."""
    h, w = frame.shape[:2]
    cx, cy = w // 2, h // 2
    col = (0, 200, 255)
    destinos = {"IZQ": (30, cy), "DER": (w - 30, cy), "ARR": (cx, 90), "ABA": (cx, h - 30)}
    if nombre == "CENTRO":
        cv2.circle(frame, (cx, cy), 40, col, 5)
        cv2.circle(frame, (cx, cy), 8, col, -1)
    else:
        dx, dy = destinos[nombre]
        # la flecha sale cerca del centro y apunta al borde
        sx, sy = cx + (dx - cx) // 3, cy + (dy - cy) // 3
        cv2.arrowedLine(frame, (sx, sy), (dx, dy), (0, 0, 0), 16, tipLength=0.35)
        cv2.arrowedLine(frame, (sx, sy), (dx, dy), col, 9, tipLength=0.35)
    cv2.putText(frame, f"{restante:.0f}", (cx - 15, cy + 12 if nombre != "CENTRO" else cy - 55),
                cv2.FONT_HERSHEY_SIMPLEX, 1.2, col, 3, cv2.LINE_AA)


def minimapa(frame, cal, m):
    """Pequeño mapa arriba a la derecha: la zona de pantalla aprendida y hacia donde miras ahora."""
    if cal.zona is None or m is None:
        return
    W, H = 130, 80
    x0, y0 = frame.shape[1] - W - 10, 10
    cv2.rectangle(frame, (x0, y0), (x0 + W, y0 + H), (40, 40, 40), -1)
    cv2.rectangle(frame, (x0 + 6, y0 + 6), (x0 + W - 6, y0 + H - 6), (200, 200, 200), 1)
    zx0, zx1, zy0, zy1 = cal.zona
    nx = (m["gx"] - zx0) / max(zx1 - zx0, 1e-6)
    ny = (m["gy"] - zy0) / max(zy1 - zy0, 1e-6)
    if not cal.izq_negativo:
        nx = 1 - nx
    if not cal.arriba_negativo:
        ny = 1 - ny
    px = int(x0 + 6 + min(max(nx, -0.3), 1.3) * (W - 12))
    py = int(y0 + 6 + min(max(ny, -0.3), 1.3) * (H - 12))
    px, py = min(max(px, x0), x0 + W), min(max(py, y0), y0 + H)
    cv2.circle(frame, (px, py), 5, (0, 255, 0) if 0 <= nx <= 1 and 0 <= ny <= 1 else (50, 50, 230), -1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--alerta", choices=["sonido", "imagen", "ambos"])
    ap.add_argument("--gif", default=GIF_PATH)
    ap.add_argument("--camara", type=int, default=CAMARA_INDEX, help="numero de camara; si se omite, la busca sola")
    ap.add_argument("--mqtt", default=None, help="IP/host del broker MQTT (si se omite, sin MQTT)")
    args = ap.parse_args()

    modo = args.alerta or pedir_modo()
    tracker = FaceTracker()
    cap = abrir_camara(args.camara)
    mon = AttentionMonitor(DISTRACT_AFTER, RECOVER_AFTER)
    calib = Calibrator()
    alertas = AlertManager(modo, args.gif, GIF_WIDTH, SOUND_PATH)
    link = MqttLink(args.mqtt, MQTT_PORT, MQTT_PREFIX) if args.mqtt else None

    alert_count, ultima_pub, mostrar_dbg = 0, 0.0, False
    log_csv(CSV_PATH, "INICIO", modo)
    t_ini = time.time()
    print("\nCALIBRACION: sigue las instrucciones de la ventana (suena un pitido en cada paso).")
    print("Mira cada zona de tu pantalla como lo harias al estudiar.\n")

    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                print("La camara dejo de responder.")
                break
            frame = cv2.flip(frame, 1)  # vista de espejo
            now = time.time()

            pts = tracker.process(frame, (now - t_ini) * 1000)
            dibujar_cara(frame, pts)

            if not calib.done:
                calib.update(pts, now)
                if not calib.done:
                    etiqueta(frame, calib.paso_texto, 10, 30, (0, 140, 255), 0.7)
                    cv2.rectangle(frame, (10, 45), (10 + int(300 * calib.progreso(now)), 55), (0, 200, 255), -1)
                    flecha_paso(frame, calib.PASOS[calib.i][0], max(0.0, CALIB_STEP_SECONDS * (1 - calib.progreso(now))))
                    if pts is None:
                        etiqueta(frame, "NO VEO TU ROSTRO: ajusta la camara / la luz", 10, 85, ROJO, 0.5)
            else:
                m = medir(pts, calib.ref, calib.base_ojo)
                mirando, texto = juzgar(m, calib)
                for ev in mon.update(mirando, now):
                    if ev == "DISTRAIDO":
                        alert_count += 1
                        alertas.start()
                        log_csv(CSV_PATH, "DISTRAIDO", mon.count)
                        if link:
                            link.publish("atencion", "DISTRAIDO", retain=True)
                            link.publish("alertas", "ON")
                    else:
                        alertas.stop()
                        log_csv(CSV_PATH, "ATENTO", round(mon.distracted_total, 1))
                        if link:
                            link.publish("atencion", "ATENTO", retain=True)
                            link.publish("alertas", "OFF")

                etiqueta(frame, texto, 10, 30, VERDE if mirando else ROJO)
                etiqueta(frame, f"Estudio {fmt(mon.study_time(now))} | Distraido {fmt(mon.distracted_total)}", 10, 62, (70, 70, 70), 0.5)
                etiqueta(frame, f"Distracciones {mon.count} | Alertas {alert_count}", 10, 90, (70, 70, 70), 0.5)
                minimapa(frame, calib, m)
                if link:
                    s = link.sensores
                    pir = "?" if s["presencia"] is None else ("SI" if s["presencia"] else "NO")
                    ruido = "?" if s["ruido"] is None else f"{s['ruido']}%"
                    etiqueta(frame, f"ESP32 {'ON' if link.connected else 'OFF'} | Presencia {pir} | Ruido {ruido}", 10, 118, (70, 70, 70), 0.5)
                if mostrar_dbg and m:
                    dbg = f"yaw={m['yaw']:.1f} pitch={m['pitch']:.1f} gx={m['gx']:.1f} gy={m['gy']:.1f} zona=[{calib.zona[0]:.0f},{calib.zona[1]:.0f}]x[{calib.zona[2]:.0f},{calib.zona[3]:.0f}]"
                    cv2.putText(frame, dbg, (10, frame.shape[0] - 12), cv2.FONT_HERSHEY_SIMPLEX, 0.45, AMARILLO, 1, cv2.LINE_AA)

                if link and now - ultima_pub >= MQTT_PERIODO:
                    ultima_pub = now
                    link.publish("tiempo", {"estudio_s": int(mon.study_time(now)), "distraido_s": int(mon.distracted_total),
                                            "distracciones": mon.count, "alertas": alert_count})

            alertas.tick()
            cv2.imshow("Monitor de concentracion", frame)
            k = cv2.waitKey(1) & 0xFF
            if k in (ord("q"), 27):
                break
            if k == ord("c"):          # recalibrar
                calib.reset()
                alertas.stop()
                mon.state, mon._off_since, mon._on_since = "ATENTO", None, None
            if k == ord("d"):
                mostrar_dbg = not mostrar_dbg
    finally:
        alertas.stop()
        resumen = f"estudio={fmt(mon.study_time(time.time()))} distraido={fmt(mon.distracted_total)} distracciones={mon.count} alertas={alert_count}"
        log_csv(CSV_PATH, "FIN", resumen)
        print("Resumen:", resumen)
        if link:
            link.close()
        cap.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
